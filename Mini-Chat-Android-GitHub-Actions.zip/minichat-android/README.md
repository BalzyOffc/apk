# Mini Chat Android — Capacitor + GitHub Actions

Project ini membungkus source `index(2).html` menjadi aplikasi Android menggunakan Capacitor. Source web asli diletakkan di `www/index.html`; workflow GitHub Actions akan membuat project Android dan menghasilkan APK debug.

## Build APK melalui GitHub Actions (bisa dari HP)

1. Buat repository GitHub baru.
2. Upload seluruh isi folder project ini ke repository (pastikan folder `.github/workflows` ikut ter-upload).
3. Buka tab **Actions** di repository.
4. Pilih workflow **Build Mini Chat APK**.
5. Tekan **Run workflow**.
6. Tunggu sampai job berstatus hijau.
7. Buka hasil run, scroll ke **Artifacts**, lalu unduh `Mini-Chat-Android-APK`.
8. Ekstrak ZIP artifact dan install `app-debug.apk` di Android. Jika diminta, izinkan instalasi aplikasi dari sumber tersebut.

Workflow juga berjalan otomatis saat ada perubahan pada `www/`, `package.json`, atau konfigurasi build di branch `main`/`master`.

## Build lokal (opsional)

Memerlukan Node.js 20+, Java 21, Android SDK, dan Android build tools.

```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

APK lokal berada di `android/app/build/outputs/apk/debug/app-debug.apk`.

## Supabase

Source saat ini masih menggunakan URL dan publishable/anon key Supabase yang sudah ada di HTML. Publishable/anon key memang digunakan di sisi klien; keamanan data harus tetap ditegakkan melalui Row Level Security (RLS). Jangan pernah menaruh `service_role` key di HTML atau APK.

File migrasi SQL lengkap disertakan di `supabase/migrations/`. Jalankan migrasi tersebut di Supabase SQL Editor pada project yang sama sebelum menggunakan fitur database.

## Catatan fitur Android

- Chat dan sinkronisasi Supabase memerlukan koneksi internet.
- Browser APIs untuk kamera/mikrofon dan WebRTC memerlukan izin Android dan perlu diuji pada perangkat nyata.
- Berbagi lokasi memerlukan izin lokasi saat aplikasi digunakan. Penggunaan lokasi di background tidak dijanjikan oleh konfigurasi dasar ini.
- Push notification Android tidak otomatis aktif hanya karena APK berhasil dibuat; perlu integrasi push provider dan konfigurasi native tambahan.
- Workflow menghasilkan **debug APK** untuk pengujian, bukan APK release bertanda tangan untuk distribusi Play Store.
