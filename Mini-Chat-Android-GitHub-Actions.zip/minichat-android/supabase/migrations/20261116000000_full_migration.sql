-- ============================================================
-- MINI CHAT - FULL SUPABASE MIGRATION
-- Dibuat berdasarkan source index(2).html
-- Jalankan seluruh file ini di Supabase SQL Editor.
-- ============================================================

begin;

create extension if not exists pgcrypto;
create schema if not exists extensions;

-- ------------------------------------------------------------
-- Helper: updated_at
-- ------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

-- ------------------------------------------------------------
-- PROFILES + AUTH
-- ------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null,
  email text,
  avatar_url text,
  bio text not null default '',
  is_verified boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists profiles_username_lower_uidx
  on public.profiles (lower(username));

create index if not exists profiles_username_idx on public.profiles(username);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_username text;
begin
  v_username := coalesce(
    nullif(trim(new.raw_user_meta_data->>'username'), ''),
    split_part(coalesce(new.email, 'user'), '@', 1)
  );
  v_username := regexp_replace(v_username, '[^a-zA-Z0-9_]', '_', 'g');
  v_username := left(v_username, 20);
  if length(v_username) < 3 then
    v_username := 'user_' || left(replace(new.id::text, '-', ''), 8);
  end if;

  insert into public.profiles(id, username, email)
  values(new.id, v_username, new.email)
  on conflict (id) do update
    set email = excluded.email;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created_mini_chat on auth.users;
create trigger on_auth_user_created_mini_chat
after insert on auth.users
for each row execute function public.handle_new_user();

create or replace function public.sync_profile_email()
returns trigger
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  update public.profiles
     set email = new.email, updated_at = now()
   where id = new.id;
  return new;
end;
$$;

drop trigger if exists on_auth_user_updated_mini_chat on auth.users;
create trigger on_auth_user_updated_mini_chat
after update of email on auth.users
for each row execute function public.sync_profile_email();

drop trigger if exists profiles_updated_at on public.profiles;
create trigger profiles_updated_at before update on public.profiles
for each row execute function public.set_updated_at();

-- ------------------------------------------------------------
-- GLOBAL CHAT
-- ------------------------------------------------------------
create table if not exists public.global_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  username text not null,
  content text not null default '',
  msg_type text not null default 'text',
  media_url text,
  meta jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  constraint global_messages_type_check check (
    msg_type in ('text','image','video','voice','audio','file','sticker','location')
  )
);
create index if not exists global_messages_created_idx
  on public.global_messages(created_at);

-- ------------------------------------------------------------
-- PRIVATE CHAT
-- ------------------------------------------------------------
create table if not exists public.private_messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  content text not null default '',
  msg_type text not null default 'text',
  media_url text,
  meta jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  constraint private_messages_not_self check (sender_id <> receiver_id),
  constraint private_messages_type_check check (
    msg_type in ('text','image','video','voice','audio','file','sticker','location')
  )
);
create index if not exists private_messages_pair_created_idx
  on public.private_messages(sender_id, receiver_id, created_at);
create index if not exists private_messages_receiver_created_idx
  on public.private_messages(receiver_id, sender_id, created_at);

-- ------------------------------------------------------------
-- GROUPS + MEMBERS + GROUP CHAT
-- ------------------------------------------------------------
create table if not exists public.groups (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 50),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  description text not null default '',
  avatar_url text,
  is_verified boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists groups_owner_idx on public.groups(owner_id);

create table if not exists public.group_members (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.groups(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  unique(group_id, user_id)
);
create index if not exists group_members_user_idx on public.group_members(user_id);
create index if not exists group_members_group_idx on public.group_members(group_id);

create table if not exists public.group_messages (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.groups(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  username text not null,
  content text not null default '',
  msg_type text not null default 'text',
  media_url text,
  meta jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  constraint group_messages_type_check check (
    msg_type in ('text','image','video','voice','audio','file','sticker','location')
  )
);
create index if not exists group_messages_group_created_idx
  on public.group_messages(group_id, created_at);

drop trigger if exists groups_updated_at on public.groups;
create trigger groups_updated_at before update on public.groups
for each row execute function public.set_updated_at();

-- ------------------------------------------------------------
-- CALLS
-- ------------------------------------------------------------
create table if not exists public.call_invites (
  id uuid primary key default gen_random_uuid(),
  room_id text not null unique,
  call_type text not null check (call_type in ('audio','video')),
  created_by uuid not null references public.profiles(id) on delete cascade,
  created_by_username text not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '24 hours')
);
create index if not exists call_invites_created_idx on public.call_invites(created_at desc);

create table if not exists public.call_signals (
  id bigint generated by default as identity primary key,
  room_id text not null,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  type text not null check (type in ('join','offer','answer','ice','hangup')),
  payload jsonb,
  created_at timestamptz not null default now()
);
create index if not exists call_signals_room_created_idx
  on public.call_signals(room_id, created_at);

create table if not exists public.call_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  room_id text not null,
  call_type text not null check (call_type in ('audio','video')),
  status text not null default 'completed',
  created_at timestamptz not null default now()
);
create index if not exists call_history_user_created_idx
  on public.call_history(user_id, created_at desc);

-- ------------------------------------------------------------
-- USER BLOCKS / BANS
-- ------------------------------------------------------------
create table if not exists public.banned_users (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  reason text,
  created_at timestamptz not null default now()
);

create table if not exists public.blocked_users (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  reason text,
  created_at timestamptz not null default now(),
  expires_at timestamptz
);

-- ------------------------------------------------------------
-- APP SETTINGS + APP UPDATES
-- ------------------------------------------------------------
create table if not exists public.app_settings (
  key text primary key,
  value text not null default '',
  updated_at timestamptz not null default now()
);

insert into public.app_settings(key, value) values
  ('maintenance', 'false'),
  ('maintenance_message', 'Aplikasi sedang dalam perbaikan. Silakan coba lagi nanti.'),
  ('registration_open', 'true'),
  ('app_version', '1.3')
on conflict (key) do nothing;

create table if not exists public.app_update_config (
  id integer primary key default 1 check (id = 1),
  latest_version text,
  index_url text,
  index_content text,
  updated_at timestamptz not null default now()
);
insert into public.app_update_config(id, latest_version)
values(1, '1.3')
on conflict (id) do nothing;

create table if not exists public.app_updates (
  id uuid primary key default gen_random_uuid(),
  version text not null,
  title text,
  description text,
  created_at timestamptz not null default now()
);
create index if not exists app_updates_created_idx on public.app_updates(created_at desc);

-- ------------------------------------------------------------
-- USER STICKERS
-- ------------------------------------------------------------
create table if not exists public.user_stickers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  url text not null,
  created_at timestamptz not null default now(),
  unique(user_id, url)
);
create index if not exists user_stickers_user_created_idx
  on public.user_stickers(user_id, created_at desc);

-- ------------------------------------------------------------
-- LIVE LOCATION
-- room_id formats: group:<uuid> or dm:<uuid>_<uuid>
-- ------------------------------------------------------------
create table if not exists public.live_locations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  username text not null,
  room_id text not null,
  lat double precision not null check (lat between -90 and 90),
  lng double precision not null check (lng between -180 and 180),
  expires_at timestamptz not null,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  unique(user_id, room_id)
);
create index if not exists live_locations_room_expiry_idx
  on public.live_locations(room_id, expires_at);

-- ------------------------------------------------------------
-- ACCESS HELPERS
-- ------------------------------------------------------------
create or replace function public.is_group_member(p_group_id uuid, p_user_id uuid default auth.uid())
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.group_members gm
    where gm.group_id = p_group_id and gm.user_id = p_user_id
  );
$$;

create or replace function public.is_group_owner(p_group_id uuid, p_user_id uuid default auth.uid())
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.groups g
    where g.id = p_group_id and g.owner_id = p_user_id
  );
$$;

create or replace function public.can_access_location_room(p_room_id text, p_user_id uuid default auth.uid())
returns boolean
language plpgsql stable security definer
set search_path = public
as $$
declare
  v_parts text[];
  v_a uuid;
  v_b uuid;
  v_group uuid;
begin
  if p_user_id is null or p_room_id is null then return false; end if;

  if p_room_id like 'group:%' then
    begin
      v_group := substring(p_room_id from 7)::uuid;
      return public.is_group_member(v_group, p_user_id);
    exception when others then
      return false;
    end;
  elsif p_room_id like 'dm:%' then
    v_parts := string_to_array(substring(p_room_id from 4), '_');
    if array_length(v_parts, 1) <> 2 then return false; end if;
    begin
      v_a := v_parts[1]::uuid;
      v_b := v_parts[2]::uuid;
      return p_user_id = v_a or p_user_id = v_b;
    exception when others then
      return false;
    end;
  end if;
  return false;
end;
$$;

-- ------------------------------------------------------------
-- RPC: GROUP LIST (dipakai source: supabase.rpc('list_my_groups'))
-- ------------------------------------------------------------
create or replace function public.list_my_groups()
returns table (
  id uuid,
  name text,
  owner_id uuid,
  description text,
  avatar_url text,
  is_verified boolean,
  created_at timestamptz,
  updated_at timestamptz
)
language sql stable security definer
set search_path = public
as $$
  select g.id, g.name, g.owner_id, g.description, g.avatar_url,
         g.is_verified, g.created_at, g.updated_at
    from public.groups g
   where auth.uid() is not null
     and (g.owner_id = auth.uid() or exists (
       select 1 from public.group_members gm
       where gm.group_id = g.id and gm.user_id = auth.uid()
     ))
   order by g.created_at desc;
$$;

-- ------------------------------------------------------------
-- RPC: LIVE LOCATION
-- ------------------------------------------------------------
create or replace function public.insert_live_location(
  p_user_id uuid,
  p_username text,
  p_room_id text,
  p_lat double precision,
  p_lng double precision,
  p_expires_at timestamptz
)
returns void
language plpgsql security definer
set search_path = public
as $$
begin
  if auth.uid() is null or auth.uid() <> p_user_id then
    raise exception 'Tidak diizinkan';
  end if;
  if not public.can_access_location_room(p_room_id, p_user_id) then
    raise exception 'Tidak memiliki akses ke ruang lokasi';
  end if;
  insert into public.live_locations(user_id, username, room_id, lat, lng, expires_at, updated_at)
  values(p_user_id, p_username, p_room_id, p_lat, p_lng, p_expires_at, now())
  on conflict(user_id, room_id) do update
    set username = excluded.username,
        lat = excluded.lat,
        lng = excluded.lng,
        expires_at = excluded.expires_at,
        updated_at = now();
end;
$$;

create or replace function public.update_live_location(
  p_user_id uuid,
  p_room_id text,
  p_lat double precision,
  p_lng double precision
)
returns void
language plpgsql security definer
set search_path = public
as $$
begin
  if auth.uid() is null or auth.uid() <> p_user_id then
    raise exception 'Tidak diizinkan';
  end if;
  update public.live_locations
     set lat = p_lat, lng = p_lng, updated_at = now()
   where user_id = p_user_id
     and room_id = p_room_id
     and expires_at > now()
     and public.can_access_location_room(p_room_id, p_user_id);
end;
$$;

-- ------------------------------------------------------------
-- ROW LEVEL SECURITY
-- ------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.global_messages enable row level security;
alter table public.private_messages enable row level security;
alter table public.groups enable row level security;
alter table public.group_members enable row level security;
alter table public.group_messages enable row level security;
alter table public.call_invites enable row level security;
alter table public.call_signals enable row level security;
alter table public.call_history enable row level security;
alter table public.banned_users enable row level security;
alter table public.blocked_users enable row level security;
alter table public.app_settings enable row level security;
alter table public.app_update_config enable row level security;
alter table public.app_updates enable row level security;
alter table public.user_stickers enable row level security;
alter table public.live_locations enable row level security;

-- Drop only policies created by this migration (safe to rerun).
do $$
declare r record;
begin
  for r in
    select schemaname, tablename, policyname
    from pg_policies
    where schemaname = 'public'
      and policyname like 'mc_%'
  loop
    execute format('drop policy if exists %I on %I.%I', r.policyname, r.schemaname, r.tablename);
  end loop;
end $$;

-- Profiles: authenticated users can browse profiles (the HTML requests email too).
create policy mc_profiles_select on public.profiles
for select to authenticated using (true);

create policy mc_profiles_update_self on public.profiles
for update to authenticated
using (id = auth.uid())
with check (id = auth.uid());

-- Global chat
create policy mc_global_select on public.global_messages
for select to authenticated using (true);
create policy mc_global_insert on public.global_messages
for insert to authenticated
with check (user_id = auth.uid());
create policy mc_global_delete_own on public.global_messages
for delete to authenticated using (user_id = auth.uid());

-- Private messages: only the two participants.
create policy mc_private_select on public.private_messages
for select to authenticated
using (sender_id = auth.uid() or receiver_id = auth.uid());
create policy mc_private_insert on public.private_messages
for insert to authenticated
with check (sender_id = auth.uid() and receiver_id <> auth.uid());
create policy mc_private_delete_own on public.private_messages
for delete to authenticated using (sender_id = auth.uid());

-- Groups
create policy mc_groups_select on public.groups
for select to authenticated
using (owner_id = auth.uid() or public.is_group_member(id, auth.uid()));
create policy mc_groups_insert on public.groups
for insert to authenticated
with check (owner_id = auth.uid());
create policy mc_groups_update_owner on public.groups
for update to authenticated
using (owner_id = auth.uid())
with check (owner_id = auth.uid());
create policy mc_groups_delete_owner on public.groups
for delete to authenticated using (owner_id = auth.uid());

-- Memberships: members can view roster; group owner can add/remove;
-- user may add themself only to an existing group (if they know its UUID).
create policy mc_group_members_select on public.group_members
for select to authenticated
using (public.is_group_member(group_id, auth.uid()) or public.is_group_owner(group_id, auth.uid()));
create policy mc_group_members_insert on public.group_members
for insert to authenticated
with check (
  public.is_group_owner(group_id, auth.uid())
  or user_id = auth.uid()
);
create policy mc_group_members_delete on public.group_members
for delete to authenticated
using (
  user_id = auth.uid()
  or public.is_group_owner(group_id, auth.uid())
);

-- Group messages
create policy mc_group_messages_select on public.group_messages
for select to authenticated
using (public.is_group_member(group_id, auth.uid()) or public.is_group_owner(group_id, auth.uid()));
create policy mc_group_messages_insert on public.group_messages
for insert to authenticated
with check (
  user_id = auth.uid()
  and (public.is_group_member(group_id, auth.uid()) or public.is_group_owner(group_id, auth.uid()))
);
create policy mc_group_messages_delete_own on public.group_messages
for delete to authenticated using (user_id = auth.uid());

-- Call invites/signaling. Any signed-in user can join a room link.
create policy mc_call_invites_select on public.call_invites
for select to authenticated using (true);
create policy mc_call_invites_insert on public.call_invites
for insert to authenticated
with check (created_by = auth.uid());
create policy mc_call_invites_delete_owner on public.call_invites
for delete to authenticated using (created_by = auth.uid());

create policy mc_call_signals_select on public.call_signals
for select to authenticated using (true);
create policy mc_call_signals_insert on public.call_signals
for insert to authenticated
with check (sender_id = auth.uid());

-- Call history is private per account.
create policy mc_call_history_select on public.call_history
for select to authenticated using (user_id = auth.uid());
create policy mc_call_history_insert on public.call_history
for insert to authenticated with check (user_id = auth.uid());
create policy mc_call_history_delete on public.call_history
for delete to authenticated using (user_id = auth.uid());

-- Moderation data: a user may read their own status, but cannot write it.
create policy mc_banned_select_self on public.banned_users
for select to authenticated using (user_id = auth.uid());
create policy mc_blocked_select_self on public.blocked_users
for select to authenticated using (user_id = auth.uid());

-- Settings visible to authenticated users; writes are dashboard/service-role only.
create policy mc_settings_select on public.app_settings
for select to authenticated using (true);
create policy mc_update_config_select on public.app_update_config
for select to authenticated using (true);
create policy mc_app_updates_select on public.app_updates
for select to authenticated using (true);

-- Stickers belong to the owner.
create policy mc_stickers_select on public.user_stickers
for select to authenticated using (user_id = auth.uid());
create policy mc_stickers_insert on public.user_stickers
for insert to authenticated with check (user_id = auth.uid());
create policy mc_stickers_delete on public.user_stickers
for delete to authenticated using (user_id = auth.uid());

-- Live location visibility follows DM participants or group membership.
create policy mc_live_locations_select on public.live_locations
for select to authenticated
using (
  expires_at > now()
  and public.can_access_location_room(room_id, auth.uid())
);
create policy mc_live_locations_delete_own on public.live_locations
for delete to authenticated using (user_id = auth.uid());

-- ------------------------------------------------------------
-- PRIVILEGES (RLS remains the actual row-level gate)
-- ------------------------------------------------------------
grant usage on schema public to anon, authenticated;
grant select on public.profiles to authenticated;
grant update (username, avatar_url, bio) on public.profiles to authenticated;

grant select, insert, delete on public.global_messages to authenticated;
grant select, insert, delete on public.private_messages to authenticated;
grant select on public.groups to authenticated;
grant insert (name, owner_id) on public.groups to authenticated;
grant update (name, description, avatar_url) on public.groups to authenticated;
grant delete on public.groups to authenticated;
grant select, insert, delete on public.group_members to authenticated;
grant select, insert, delete on public.group_messages to authenticated;
grant select, insert, delete on public.call_invites to authenticated;
grant select, insert on public.call_signals to authenticated;
grant select, insert, delete on public.call_history to authenticated;
grant select on public.banned_users, public.blocked_users to authenticated;
grant select on public.app_settings, public.app_update_config, public.app_updates to authenticated;
grant select, insert, delete on public.user_stickers to authenticated;
grant select, delete on public.live_locations to authenticated;

grant execute on function public.list_my_groups() to authenticated;
grant execute on function public.insert_live_location(uuid,text,text,double precision,double precision,timestamptz) to authenticated;
grant execute on function public.update_live_location(uuid,text,double precision,double precision) to authenticated;
grant execute on function public.is_group_member(uuid,uuid) to authenticated;
grant execute on function public.is_group_owner(uuid,uuid) to authenticated;
grant execute on function public.can_access_location_room(text,uuid) to authenticated;

-- ------------------------------------------------------------
-- STORAGE BUCKETS
-- ------------------------------------------------------------
insert into storage.buckets(id, name, public, file_size_limit, allowed_mime_types)
values
  ('avatars', 'avatars', true, 2097152, array['image/jpeg','image/png','image/webp','image/gif']),
  ('stickers', 'stickers', true, 5242880, array['image/png','image/webp','image/gif','image/jpeg']),
  ('chat-media', 'chat-media', true, 52428800, array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','audio/webm','audio/ogg','audio/mp4','application/pdf','text/plain','application/zip','application/octet-stream'])
on conflict (id) do update
set public = excluded.public,
    file_size_limit = excluded.file_size_limit,
    allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists mc_avatars_public_read on storage.objects;
drop policy if exists mc_avatars_upload_own_folder on storage.objects;
drop policy if exists mc_avatars_update_own_folder on storage.objects;
drop policy if exists mc_avatars_delete_own_folder on storage.objects;
drop policy if exists mc_avatars_upload_root_name on storage.objects;
drop policy if exists mc_avatars_update_root_name on storage.objects;
drop policy if exists mc_avatars_delete_root_name on storage.objects;
drop policy if exists mc_stickers_public_read on storage.objects;
drop policy if exists mc_chat_media_public_read on storage.objects;
drop policy if exists mc_chat_media_upload_own_folder on storage.objects;
drop policy if exists mc_chat_media_update_own_folder on storage.objects;
drop policy if exists mc_chat_media_delete_own_folder on storage.objects;
drop policy if exists mc_stickers_upload_own_folder on storage.objects;
drop policy if exists mc_stickers_update_own_folder on storage.objects;
drop policy if exists mc_stickers_delete_own_folder on storage.objects;

create policy mc_avatars_public_read on storage.objects
for select using (bucket_id = 'avatars');
-- Source avatar uploader stores files at root as <auth.uid()>-<timestamp>.<ext>.
create policy mc_avatars_upload_root_name on storage.objects
for insert to authenticated
with check (bucket_id = 'avatars' and name like auth.uid()::text || '-%');
create policy mc_avatars_update_root_name on storage.objects
for update to authenticated
using (bucket_id = 'avatars' and name like auth.uid()::text || '-%')
with check (bucket_id = 'avatars' and name like auth.uid()::text || '-%');
create policy mc_avatars_delete_root_name on storage.objects
for delete to authenticated
using (bucket_id = 'avatars' and name like auth.uid()::text || '-%');

create policy mc_stickers_public_read on storage.objects
for select using (bucket_id = 'stickers');
create policy mc_stickers_upload_own_folder on storage.objects
for insert to authenticated
with check (bucket_id = 'stickers' and (storage.foldername(name))[1] = auth.uid()::text);
create policy mc_stickers_update_own_folder on storage.objects
for update to authenticated
using (bucket_id = 'stickers' and owner_id = auth.uid()::text)
with check (bucket_id = 'stickers' and owner_id = auth.uid()::text);
create policy mc_stickers_delete_own_folder on storage.objects
for delete to authenticated
using (bucket_id = 'stickers' and owner_id = auth.uid()::text);

-- Chat media upload helper stores files under <uid>/<folder>/<filename>.
create policy mc_chat_media_public_read on storage.objects
for select using (bucket_id = 'chat-media');
create policy mc_chat_media_upload_own_folder on storage.objects
for insert to authenticated
with check (bucket_id = 'chat-media' and (storage.foldername(name))[1] = auth.uid()::text);
create policy mc_chat_media_update_own_folder on storage.objects
for update to authenticated
using (bucket_id = 'chat-media' and (storage.foldername(name))[1] = auth.uid()::text)
with check (bucket_id = 'chat-media' and (storage.foldername(name))[1] = auth.uid()::text);
create policy mc_chat_media_delete_own_folder on storage.objects
for delete to authenticated
using (bucket_id = 'chat-media' and (storage.foldername(name))[1] = auth.uid()::text);

-- ------------------------------------------------------------
-- REALTIME PUBLICATION (idempotent)
-- ------------------------------------------------------------
do $$
declare t text;
begin
  if not exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    execute 'create publication supabase_realtime';
  end if;

  foreach t in array array[
    'global_messages',
    'private_messages',
    'group_messages',
    'call_signals',
    'app_updates'
  ] loop
    if not exists (
      select 1
      from pg_publication_tables
      where pubname = 'supabase_realtime'
        and schemaname = 'public'
        and tablename = t
    ) then
      execute format('alter publication supabase_realtime add table public.%I', t);
    end if;
  end loop;
end $$;

commit;

-- ============================================================
-- SETUP ADMIN / OWNER (manual, after the account is registered)
-- Ganti email dengan email akun admin yang sudah dibuat.
-- Jangan pernah memberi role admin lewat input publik frontend.
--
-- Untuk mengaktifkan centang verified pada profil:
-- update public.profiles set is_verified = true
-- where id = (select id from auth.users where email = 'email-admin@example.com');
--
-- Admin dashboard tidak ditemukan pada source HTML ini. Pengaturan,
-- ban/block, dan app_update_config harus diubah melalui Supabase Dashboard
-- atau backend tepercaya dengan service_role key (JANGAN di HTML).
-- ============================================================
