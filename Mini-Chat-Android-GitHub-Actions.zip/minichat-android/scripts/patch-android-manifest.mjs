import fs from 'node:fs';

const file = 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(file)) throw new Error(`AndroidManifest tidak ditemukan: ${file}`);
let xml = fs.readFileSync(file, 'utf8');
const permissions = [
  'android.permission.INTERNET',
  'android.permission.CAMERA',
  'android.permission.RECORD_AUDIO',
  'android.permission.MODIFY_AUDIO_SETTINGS',
  'android.permission.ACCESS_COARSE_LOCATION',
  'android.permission.ACCESS_FINE_LOCATION',
  'android.permission.POST_NOTIFICATIONS'
];
for (const permission of permissions) {
  if (!xml.includes(`android:name="${permission}"`)) {
    xml = xml.replace('<application', `    <uses-permission android:name="${permission}" />\n    <application`);
  }
}
if (!xml.includes('android.hardware.camera')) {
  xml = xml.replace('<application', '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n    <uses-feature android:name="android.hardware.microphone" android:required="false" />\n    <application');
}
fs.writeFileSync(file, xml);
console.log('Android permissions added to manifest.');
